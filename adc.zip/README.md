EE319K_Game
===========

Final project for EE319K, Introduction to Embedded Systems.

Project Goal
------------
Design a re-skin of Space Invaders to run on the Tiva Launchpad.

Features
--------
Single player mode: standard space invaders gameplay format
Multiplayer: fight against another player 

